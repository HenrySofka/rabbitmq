package com.sofka.broker.adapter;

import com.sofka.broker.model.User;
import org.reactivecommons.async.api.HandlerRegistry;
import org.reactivecommons.async.impl.config.annotations.EnableCommandListeners;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

import static org.reactivecommons.async.api.HandlerRegistry.register;

@Configuration
@EnableCommandListeners
public class UserAsyncAdapter {

    private List<User> users = new ArrayList<>();

    @Bean
    public HandlerRegistry commandSaveUserSubscription() {
        return register().handleCommand("user.save",
                user -> {
                    users.add(user.getData());
                    return Mono.empty();
                }, User.class);
    }

    @Bean
    public HandlerRegistry queryExistSubscription() {
        return register()
                .serveQuery("user.exist", user -> {
                    return Mono.just(user);
                }, User.class);
    }

}
