package com.sofka.broker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrokerReceiverApplicationTests {

	@Test
	void contextLoads() {
	}

}
