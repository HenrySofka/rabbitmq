package com.sofka.broker.adapter;

import com.sofka.broker.model.User;
import com.sofka.broker.model.gateway.UserGateway;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class UserMessageAsyncAdapter implements UserGateway {
    @Override
    public Mono<Boolean> save(User user) {
        return Mono.just(Boolean.TRUE);
    }

    @Override
    public Mono<Boolean> exist(User user) {
        return Mono.just(Boolean.TRUE);
    }
}
